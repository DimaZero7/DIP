from django.apps import AppConfig


class AccountConfig(AppConfig):
    name = 'account'
    verbose_name='Аккаунт'
    verbose_name_plural = 'Аккаунты'