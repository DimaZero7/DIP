from django.apps import AppConfig


class PosterConfig(AppConfig):
    name = 'poster'
