from django.apps import AppConfig


class ManufactureConfig(AppConfig):
    name = 'manufacture'
    verbose_name='Производители'