from django.apps import AppConfig


class BasketConfig(AppConfig):
    name = 'basket'
    verbose_name='Заказ'
    verbose_name_plural = 'Заказы'